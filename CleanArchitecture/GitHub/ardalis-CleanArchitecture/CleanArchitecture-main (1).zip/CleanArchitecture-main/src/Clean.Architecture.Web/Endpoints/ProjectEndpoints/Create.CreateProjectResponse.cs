﻿namespace Clean.Architecture.Web.Endpoints.ProjectEndpoints
{
    public class CreateProjectResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}