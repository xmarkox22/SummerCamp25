﻿namespace Clean.Architecture.Web.Endpoints.ProjectEndpoints
{
    public class UpdateProjectResponse
    {
        public ProjectRecord Project { get; set; }
    }
}