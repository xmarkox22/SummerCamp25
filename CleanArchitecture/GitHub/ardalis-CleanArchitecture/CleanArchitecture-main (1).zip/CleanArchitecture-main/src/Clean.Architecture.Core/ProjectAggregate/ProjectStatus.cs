﻿namespace Clean.Architecture.Core.ProjectAggregate
{
    public enum ProjectStatus
    {
        InProgress,
        Complete
    }
}
