---
name: Bug report
about: Create a report to help us improve
---
<!-- ⚠️⚠️ Do Not Delete This! bug_report_template ⚠️⚠️ -->
<!-- 🔎 Search existing issues to avoid creating duplicates. -->

- .NET SDK Version:

Steps to Reproduce:

1.
2.
